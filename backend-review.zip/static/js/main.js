console.log("Ладно loaded");
